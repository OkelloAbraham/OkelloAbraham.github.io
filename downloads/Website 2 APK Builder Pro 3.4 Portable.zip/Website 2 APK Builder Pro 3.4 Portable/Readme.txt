- Run app!
Java has to be installed of course

Note: ProPlus version is not possible because push notification is handled serverside from developer.


www.ShareAppsCrack.com